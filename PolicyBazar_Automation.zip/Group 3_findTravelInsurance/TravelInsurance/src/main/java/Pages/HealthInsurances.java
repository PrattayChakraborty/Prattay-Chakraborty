package Pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.Status;

import Base.Base;

public class HealthInsurances extends Base{
	
	
	public void list() throws InterruptedException, IOException {
		WebElement hov=driver.findElement(By.xpath("/html/body/div[4]/div[2]/div/ul/li[2]/a"));
		Actions act=new Actions(driver);
		act.moveToElement(hov).perform();
		screenshot_capture.CaptureScreenshot(driver, "insHlth.png");
	    exttest = report.createTest("To Display the Health Insurance Menu list");

		System.out.println("*****************************************************");
		System.out.println("        The Health Isurance Menu Items are: ");
		System.out.println("*****************************************************");
		List<WebElement> insuranceList=driver.findElements(By.xpath("//*[contains(@href,'/health-insurance/')]/span[@itemprop='name']"));
		for(int j=1;j<insuranceList.size();j++)
		{
			System.out.println(insuranceList.get(j).getText());
		}
		exttest.log(Status.PASS, "Health Insurance Menu List is obtained");
	}

}
