package Pages;

import java.io.IOException;

import org.openqa.selenium.By;

import com.aventstack.extentreports.Status;

import Base.Base;

public class CarInsurance extends Base{
	
	By car=By.xpath("/html/body/main/div[2]/section/div[4]/a/div[1]/p");
	By proceed=By.xpath("//a[@class=\"btn-proceed\"]");
	By num=By.xpath("//*[@id=\"searchInput\"]/div/input");
	By slt=By.id("react-autowhatever-1");
	By cmp=By.xpath("//input[@placeholder='Search car brand']");
	By fuel=By.id("Diesel");
	By var=By.xpath("//*[text()='CRDI (1493 cc)']");
	By yr=By.xpath("//*[text()='2018']");
	By nme=By.id("name");
	By mail=By.id("email");
	By phn=By.xpath("//*[@id=\"dvVariant\"]/div[2]/div[1]/div[3]/label");
	By view=By.xpath("//*[@id=\"btnLeadDetails\"]/span");
	By err1=By.xpath("//div[@class='msg-error show']");
	By err2=By.xpath("//*[@id=\"dvVariant\"]/div[2]/div[1]/div[3]/div[1]");
	
	public void car() throws InterruptedException, IOException {
		
		exttest = report.createTest("To Display Error Messages in Car Insurance");
	
		driver.findElement(car).click();
		driver.findElement(proceed).click();
		driver.findElement(num).sendKeys("WB04");
		wait(20, slt);
		driver.findElement(slt).click();
		driver.findElement(cmp).sendKeys("accent");
		wait(20, slt);
		driver.findElement(slt).click();
		Thread.sleep(1000);
		driver.findElement(fuel).click();
		driver.findElement(var).click();
		driver.findElement(yr).click();
		exttest.log(Status.PASS, "Items are being Selected");
		driver.findElement(nme).sendKeys("Prattay");
		driver.findElement(mail).sendKeys("chakPar"
				+ "@gmail");
		screenshot_capture.CaptureScreenshot(driver, "user.png");
		System.out.println("********************************************");
		System.out.println("         The Error Message is: ");
		System.out.println("********************************************");
		System.out.println(driver.findElement(err1).getText());
		exttest.log(Status.PASS, "Errors are obtained");
		
		Thread.sleep(1000);
	}
}
