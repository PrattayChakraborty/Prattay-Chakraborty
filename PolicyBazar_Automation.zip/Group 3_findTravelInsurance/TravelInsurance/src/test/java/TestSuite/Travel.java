package TestSuite;

import java.io.IOException;

import org.testng.annotations.Test;

import Pages.CarInsurance;
import Pages.HealthInsurances;
import Pages.TravelInsurance;


public class Travel {
	
	@Test
	public void testing() throws InterruptedException, IOException
	{
		TravelInsurance ti= new TravelInsurance();
		CarInsurance ci= new CarInsurance();
		HealthInsurances hi= new HealthInsurances();
		ti.driverSetup();
		ti.openUrl();
		ti.travel();
		//ti.closeBrowser();
		
		//ci.closeBrowser();
		hi.openUrl();
		hi.list();
		ci.openUrl();
		ci.car();
		ci.closeBrowser();
    }

}
